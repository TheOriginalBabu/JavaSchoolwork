

import java.io.File;//required for file access (reading)
import java.io.FileNotFoundException;
import java.io.FileWriter;//required for file access (writing)
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * author: Izaan
 * date: 30-Mar-2022
 * filename: IzaanLab4.java
 * description: this is my lab 4 for sorting algorithms
 */
public class IzaanLab4 {
    /**
     * saveFile will store the data stored in the array of ints to fileName.txt
     * (stored in the same directory as the .java file).
     * @param fileName The name of the file where our ints will be stored.
     */
    public static void saveFile(String fileName, int[] array){
        //In java we can read from and write to files with relative ease.
        //We MUST place file access inside a try catch that catches at least
        //IOException or our code will not compile.
        try{
            //creates (or opens) the file called filename.txt
            FileWriter writeArray = new FileWriter(fileName + ".txt");
            for (int i : array) {
                //the data written must be a String or char.
                String line = Integer.toString(i);
                writeArray.write(line + '\n');//writes the data stored in line to the file
            }
            //closes the file (should be done to avoid memory leaks, and file conflicts)
            writeArray.close();
        }catch (IOException  e){
            System.out.println("File could not be created!");
        }
    }

    public static void saveResults(long time, long iterations, String algorithm, String arrayType) {
        //In java we can read from and write to files with relative ease.
        //We MUST place file access inside a try catch that catches at least
        //IOException or our code will not compile.


        String results = "\n\t\t" + arrayType + " " + algorithm + ":\n\t\t\t" + "Time: " + time + "ms\n\t\t\t" + "Iterations: " + iterations + "\n";


        try{
            //creates (or opens) the file called filename.txt
            try (FileWriter writeArray = new FileWriter("Results.txt", true)) {
                writeArray.append(results);
            }
        }catch (IOException  e){
            System.out.println("File could not be created!");
        }
    }


    /**
     * generateArrayInt will open the text file called fileName that is
     * (stored in the same directory as the .java file). It will then
     * read each int stored in that file into an array of ints and return it
     * @param fileName The name of the file where our ints are stored.
     * @return an int array of the read data.
     */

    //start of c


    //end of c

    public static int[] generateArrayInt(String fileName){ // Reads array from file
        //In java we can read from and write to files with relative ease.
        //We MUST place file access inside a try catch that catches at least the 
        //FileNotFoundException or our code will not compile.
        int array[];

        try{
            File saveFile = new File(fileName+".txt");
            //We still can use scanners to read input.
            Scanner fileScanner =new Scanner(saveFile);//notice how the parameters have changed?
            int fileLength = 0; //used to determine the length of our array
            while(fileScanner.hasNextLine()){//as long as there is a next line.
                fileScanner.nextLine();
                fileLength++;//increase the counter so we learn how many lines are in the file.
            }//end of while
            array = new int[fileLength];
            fileScanner =new Scanner(saveFile); //reset our scanner to read the file again.
            int counter = 0;
            while(fileScanner.hasNextLine()){
                //reads the line and converts to an int.
                array[counter] = Integer.parseInt(fileScanner.nextLine());
                counter++;
            }
            fileScanner.close();//closes the Scanner to avoid memory leaks
        }catch (FileNotFoundException e){
            System.out.println("File not found!");
            return new int[1];
        }
        return array;
    }
    
    /**
     * generateArrayInt is used to return an array of integers 
     * of length size. These integers can be sorted in ascending,
     * descending or random orders (determined by type). If
     * an invalid choice type is given, an array of 0's will be returned.
     * @param type determines the type of array returned.
     *             random: an array of random ints (from 0 to size)
     *             ascending: an array of sorted ints (0 to size-1)
     *             descending: an array of sorted ints (size-1 to 0) 
     * @param size determines the size of the array. 
     *             invalid sizes instead will return an array of length 1.
     * @return - an array of length size prefilled with integers.
     */
    public static int[] generateArrayInt(String type, int size){ // Generates an array of ints
        if (size<=0){ //To handle 0 or negative array sizes.
            size = 1;
        }
        int array[] = new int[size];
        switch (type) {
            case "random" -> {
                for (int x = 0; x < size; x++) {
                    array[x] = (int) (Math.random() * size);
                }
            }
            case "ascending" -> {
                for (int x = 0; x < size; x++) {
                    array[x] = x;
                }
            }
            case "descending" -> {
                for (int x = 0; x < size; x++) {
                    array[x] = size - x;
                }
            }
        }//end of switch
        return array;
    }//end of generateArrayInt
/**
 * insertionSort will return an array of integers sorted from lowest to highest.
 * It does this through an insertion sorting algorithm.
 * This algorithm functions by comparing a target element (starting at index 1)
 * to all elements to the left of it (lower indexes in the array).
 * If the element to the left is lower,  they are swapped (higher to the right).
 * This repeats until target is not less than the element to its left.
 * When this occurs, the target is considered sorted, and
 * The process restarts with the new target being the right most unsorted element.
 *
 * @param array is an array of ints to be sorted
 * @return the sorted array of ints.
 */

    public static long insertionSort(int[] array, String arrayType) { // Insertion Sort,
        long startTime = System.currentTimeMillis(); // starting time
        long counter =0; //used to count the number of iterations (not necessary)
        for (int i =1;i<array.length;i++){ //loops through each element (left to right)
            int target = array[i]; //target to be placed in sorted postion.
            int left = i -1; //elements left of the target
            while (left>=0 && array[left] > target){
                counter++;
                //while the target is not in left most sorted postion
                array[left+1] = array[left];// swaps elements to the right.
                left--;
                if (System.currentTimeMillis() - startTime > 60000) { // if the array is not sorted after 60 seconds
                    System.out.println("Array not sorted after 60 seconds.");
                    saveResults(60000, counter, "Insertion Sort - FAILED", arrayType); // saves results indicating failure
                    return counter;
                }
            }
            array[left+1] = target;
        }
        long timeTaken = System.currentTimeMillis() - startTime; // ending time,
        System.out.println("Array sorted after " + counter + " loops and " + timeTaken + " milliseconds.");
        saveResults(timeTaken, counter, "Insertion Sort", arrayType); // saves results to file within method itself
        return counter;
    }

    public static long bubbleSort(int array[], String arrayType){ // Bubble sort,
        long startTime = System.currentTimeMillis(); // starting time
        long counter =0; // used to count the number of iterations (not necessary)
        for (int i =0;i<array.length;i++) { //loops through each element (left to right)
            for (int j = 0; j < array.length - 1; j++) {
                counter++;
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
                if (System.currentTimeMillis() - startTime > 60000) { // if the array is not sorted after 60 seconds
                    System.out.println("Array not sorted after 60 seconds.");
                    saveResults(60000, counter, "Bubble Sort - FAILED", arrayType); // saves results indicating failure
                    return counter;
                }
            }
        }
        long timeTaken = System.currentTimeMillis() - startTime; // ending time
        System.out.println("Array sorted after " + counter + " loops and " + timeTaken + " milliseconds.");
        saveResults(timeTaken, counter, "Bubble Sort", arrayType); // saves results to file within method itself
        return counter;
    }

    public static long selectionSort(int array[], String arrayType){  // Selection sort
        long startTime = System.currentTimeMillis(); // starting time
        long counter =0; // used to count the number of iterations (not necessary)
        for (int i =0;i<array.length;i++){
            int min = i;
            for (int j =i+1;j<array.length;j++){
                counter++;
                if (array[j] < array[min]){
                    min = j;
                }
                if (System.currentTimeMillis() - startTime > 60000) { // if the array is not sorted after 60 seconds
                    System.out.println("Array not sorted after 60 seconds.");
                    saveResults(60000, counter, "Selection Sort - FAILED", arrayType); // saves results indicating failure
                    return counter;
                }
            }
            int temp = array[i];
            array[i] = array[min];
            array[min] = temp;
        }
        long timeTaken = System.currentTimeMillis() - startTime; // ending time
        System.out.println("Array sorted after " + counter + " loops and " + timeTaken + " milliseconds.");
        saveResults(timeTaken, counter, "Selection Sort", arrayType); // saves results to file within method itself
        return counter;
    }

    public static long gnomeSort(int array[], String arrayType){ // Gnome sort - found off "https://iq.opengenus.org/gnome-sort/"
        long startTime = System.currentTimeMillis(); // starting time
        long counter =0; // used to count the number of iterations (not necessary)
        int i = 1; // starting index
        while (i < array.length){ // loops through each element (left to right)
            counter++; // counts the number of iterations
            if (array[i-1] <= array[i]){ // if the element to the left is less than or equal to the target
                i++; // move to the next element
            }else{ // if the element to the left is greater than the target
                int temp = array[i]; // temporary variable to allow for swap
                array[i] = array[i-1]; // swaps left element to the right
                array[i-1] = temp; // store to temporary variable
                i--; // move to the previous element
                if (i == 0){ // if the target is the left most element
                    i = 1; // move to the next element
                }
            }
            if (System.currentTimeMillis() - startTime > 60000) { // if the array is not sorted after 60 seconds
                System.out.println("Array not sorted after 60 seconds.");
                saveResults(60000, counter, "Gnome Sort - FAILED", arrayType); // saves results indicating failure
                return counter;
            }
        }
        long timeTaken = System.currentTimeMillis() - startTime; // ending time
        System.out.println("Array sorted after " + counter + " loops and " + timeTaken + " milliseconds.");
        saveResults(timeTaken, counter, "Gnome Sort", arrayType); // saves results to file within method itself
        return counter;
    }
    
    public static void displayArray(int array[]){ // Method to print out Array, unused
        for (int i : array) {
            System.out.println(i);
        }    
    }

    public static void initiaizeArrays(){ // Method to initialize arrays
        int[] ascending10 = generateArrayInt("ascending", 10);
        saveFile("ascending10", ascending10);
        int[] ascending100 = generateArrayInt("ascending", 100);
        saveFile("ascending100", ascending100);
        int[] ascending1000 = generateArrayInt("ascending", 1000);
        saveFile("ascending1000", ascending1000);
        int[] ascending10000 = generateArrayInt("ascending", 10000);
        saveFile("ascending10000", ascending10000);
        int[] ascending1000000 = generateArrayInt("ascending", 1000000);
        saveFile("ascending1000000", ascending1000000);
        int[] ascending10000000 = generateArrayInt("ascending", 10000000);
        saveFile("ascending10000000", ascending10000000);

        int[] descending10 = generateArrayInt("descending", 10);
        saveFile("descending10", descending10);
        int[] descending100 = generateArrayInt("descending", 100);
        saveFile("descending100", descending100);
        int[] descending1000 = generateArrayInt("descending", 1000);
        saveFile("descending1000", descending1000);
        int[] descending10000 = generateArrayInt("descending", 10000);
        saveFile("descending10000", descending10000);
        int[] descending1000000 = generateArrayInt("descending", 1000000);
        saveFile("descending1000000", descending1000000);
        int[] descending10000000 = generateArrayInt("descending", 10000000);
        saveFile("descending10000000", descending10000000);

        int[] random10 = generateArrayInt("random", 10);
        saveFile("random10", random10);
        int[] random100 = generateArrayInt("random", 100);
        saveFile("random100", random100);
        int[] random1000 = generateArrayInt("random", 1000);
        saveFile("random1000", random1000);
        int[] random10000 = generateArrayInt("random", 10000);
        saveFile("random10000", random10000);
        int[] random1000000 = generateArrayInt("random", 1000000);
        saveFile("random1000000", random1000000);
        int[] random10000000 = generateArrayInt("random", 10000000);
        saveFile("random10000000", random10000000);
    }

    public static void main(String[] args) { // I WOULD LIKE TO THOROUGHLY APOLOGIZE FOR WHAT YOU ARE ABOUT TO WITNESS BELOW
        initiaizeArrays(); // generates all the arrays on run, and saves them to files

        int[] currentArray = generateArrayInt("ascending10");
        insertionSort(currentArray, "ascending10");
        bubbleSort(currentArray, "ascending10");
        selectionSort(currentArray, "ascending10");
        gnomeSort(currentArray, "ascending10");

        currentArray = generateArrayInt("ascending100");
        insertionSort(currentArray, "ascending100");
        bubbleSort(currentArray, "ascending100");
        selectionSort(currentArray, "ascending100");
        gnomeSort(currentArray, "ascending100");

        currentArray = generateArrayInt("ascending1000");
        insertionSort(currentArray, "ascending1000");
        bubbleSort(currentArray, "ascending1000");
        selectionSort(currentArray, "ascending1000");
        gnomeSort(currentArray, "ascending1000");

        currentArray = generateArrayInt("ascending10000");
        insertionSort(currentArray, "ascending10000");
        bubbleSort(currentArray, "ascending10000");
        selectionSort(currentArray, "ascending10000");
        gnomeSort(currentArray, "ascending10000");

        currentArray = generateArrayInt("ascending1000000");
        insertionSort(currentArray, "ascending1000000");
        bubbleSort(currentArray, "ascending1000000");
        selectionSort(currentArray, "ascending1000000");
        gnomeSort(currentArray, "ascending1000000");

        currentArray = generateArrayInt("ascending10000000");
        insertionSort(currentArray, "ascending10000000");
        bubbleSort(currentArray, "ascending10000000");
        selectionSort(currentArray, "ascending10000000");
        gnomeSort(currentArray, "ascending10000000");

        currentArray = generateArrayInt("descending10");
        insertionSort(currentArray, "descending10");
        bubbleSort(currentArray, "descending10");
        selectionSort(currentArray, "descending10");
        gnomeSort(currentArray, "descending10");

        currentArray = generateArrayInt("descending100");
        insertionSort(currentArray, "descending100");
        bubbleSort(currentArray, "descending100");
        selectionSort(currentArray, "descending100");
        gnomeSort(currentArray, "descending100");

        currentArray = generateArrayInt("descending1000");
        insertionSort(currentArray, "descending1000");
        bubbleSort(currentArray, "descending1000");
        selectionSort(currentArray, "descending1000");
        gnomeSort(currentArray, "descending1000");

        currentArray = generateArrayInt("descending10000");
        insertionSort(currentArray, "descending10000");
        bubbleSort(currentArray, "descending10000");
        selectionSort(currentArray, "descending10000");
        gnomeSort(currentArray, "descending10000");

        currentArray = generateArrayInt("descending1000000");
        insertionSort(currentArray, "descending1000000");
        bubbleSort(currentArray, "descending1000000");
        selectionSort(currentArray, "descending1000000");
        gnomeSort(currentArray, "descending1000000");

        currentArray = generateArrayInt("descending10000000");
        insertionSort(currentArray, "descending10000000");
        bubbleSort(currentArray, "descending10000000");
        selectionSort(currentArray, "descending10000000");
        gnomeSort(currentArray, "descending10000000");

        currentArray = generateArrayInt("random10");
        insertionSort(currentArray, "random10");
        bubbleSort(currentArray, "random10");
        selectionSort(currentArray, "random10");
        gnomeSort(currentArray, "random10");

        currentArray = generateArrayInt("random100");
        insertionSort(currentArray, "random100");
        bubbleSort(currentArray, "random100");
        selectionSort(currentArray, "random100");
        gnomeSort(currentArray, "random100");

        currentArray = generateArrayInt("random1000");
        insertionSort(currentArray, "random1000");
        bubbleSort(currentArray, "random1000");
        selectionSort(currentArray, "random1000");
        gnomeSort(currentArray, "random1000");

        currentArray = generateArrayInt("random10000");
        insertionSort(currentArray, "random10000");
        bubbleSort(currentArray, "random10000");
        selectionSort(currentArray, "random10000");
        gnomeSort(currentArray, "random10000");

        currentArray = generateArrayInt("random1000000");
        insertionSort(currentArray, "random1000000");
        bubbleSort(currentArray, "random1000000");
        selectionSort(currentArray, "random1000000");
        gnomeSort(currentArray, "random1000000");

        currentArray = generateArrayInt("random10000000");
        insertionSort(currentArray, "random10000000");
        bubbleSort(currentArray, "random10000000");
        selectionSort(currentArray, "random10000000");
        gnomeSort(currentArray, "random10000000");

    }
}
